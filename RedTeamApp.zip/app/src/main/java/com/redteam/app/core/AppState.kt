package com.redteam.app.core

object AppState {
    var status: String = "IDLE"
}
